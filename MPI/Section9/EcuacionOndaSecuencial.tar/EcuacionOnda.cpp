#include <bits/stdc++.h>
#define MAXPOINTS 1000
#define MAXSTEPS 1000
#define MINPOINTS 20
#define PI 3.14159265
using namespace std;
int tpoints;
int nsteps;

double values[MAXPOINTS+2];	// valores en t
double oldval[MAXPOINTS+2];	// valores en t-dt
double newval[MAXPOINTS+2];	// valotes en t+dt

void init_param();
void init_line();
void update();
void printfinal();

int main(int argc,char *argv[])
{
	init_param();
	init_line();
	update();
	printfinal();
}

void init_line()
{
	double x,fac,k,tmp;
	// Calcular valores iniciales basados en la curva seno
	fac = 3.0 * PI;
	k = 0.002;
	tmp = tpoints - 1;
	for(int j=1;j<=tpoints;j++)
	{
		x = k/tmp;
		values[j] = sin(fac * x);
		k+=1.0;
	} 
	//Inicializar valores antiguos
	for(int i=1;i<=tpoints;i++)
		oldval[i] = values[i];

}


void do_math(int i)
{
	double dtime,c,dx,tau,sqtau;

	dtime= 0.3;
	c=1.0;
	dx = 1.0;
	tau = (c*dtime/dx);
	sqtau = tau * tau;

	newval[i] = (2.0 * values[i]) - oldval[i] + (sqtau * (values[i-1] - (2.0 * values[i]) + values[i+1]));
	//newval[i] = values[i] + (dtime * 0.002 /dx * dx ) * (values[i-1] - 2.0 * values[i] + values[i+1]);
	//newval[i] = 2.0 * values[i] - oldval[i] - (values[i+1] - 2.0 * values[i] + values[i-1])*(c*c*dtime*dtime)/(dx*dx);
}

void update()
{
	for(int i=1;i<=nsteps;i++)
	{
		for(int j=1;j<=tpoints;j++)
		{
			if(j==i || j==tpoints)
				newval[j]=0.0;
			else 
				do_math(j);
		}

		for(int j=1;j<=tpoints;j++)
		{
			oldval[j] = values[j];
			values[j] = newval[j];
		}
	}
}

void init_param()
{
	tpoints = 50;
	nsteps = 500;
}

void printfinal()
{
	/*for(int i=1;i<=tpoints;i++)
	{
		cout<<i<<" "<<values[i]<<endl;
	}*/

	int i; 
  	FILE *f;
  	f=fopen("ondaPoints.txt","w");
  	for(i=1;i<=tpoints;i++){
    	printf("%d %.5lf\n",i,values[i]);
    	fprintf(f,"%lf\n",values[i]);
  	}
  	fclose(f);
}